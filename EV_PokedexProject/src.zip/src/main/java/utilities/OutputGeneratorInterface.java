package utilities;

public interface OutputGeneratorInterface {
    public String generateText(int i, int db);
    public String generateHtml( int i, int db);
}
